package com.example.hotgearvn.constants;

public class MyPreferenceKey {
    public static final String MYPREFERENCES = "MyPrefs";
    public static final String USERNAME = "UsernameKey";
    public static final String PASSWORD = "PasswordKey";
    public static final String PHONE = "PhoneKey";
    public static final String FULLNAME = "FullnameKey";
    public static final String USERID = "UseridKey";
    public static final String EMAIL = "EmailKey";
    public static final String ADDRESS = "AddressKey";

    public static final String STATUS = "StatusKey";
    public static final String  SAVEINFO = "SaveinfoKey";

    public static final String PRODUCTINCART = "ProductInCart";
}
