package com.example.hotgearvn.repository;

public class UserRepository {
}
